﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ExpressionConverter
{
    // http://stackoverflow.com/questions/11164009/using-a-linq-expressionvisitor-to-replace-primitive-parameters-with-property-ref
    public class Converter
    {
        public Expression<Func<OrderDto, int, bool>> ConvertExpression(Expression<Func<DomainOrder,int,bool>> expressionToTransform)
        {
            //var orderParameter = Expression.Parameter(typeof(OrderDto), "orderDto");
            //var idParameter = Expression.Parameter(typeof (int), "id");
            //var visitor = new ReplaceVisitor();
            //var newExpression = Expression.Lambda<Func<OrderDto, bool>>(visitor.Modify(expressionToTransform.Body, orderParameter), orderParameter);
            ////var returnExpression = visitor.Modify(newExpression, orderParameter);
            //return newExpression;
            var result = ParameterReplacer.Replace<Func<DomainOrder, int, bool>, Func<OrderDto,int,bool>>
                (expressionToTransform,Expression.Parameter(typeof (DomainOrder)), Expression.Parameter(typeof (OrderDto)));

            return result;
        }

        public Expression Convert2(Expression<Func<DomainOrder, int, bool>> expressionToTransform)
        {
            var numParam = Expression.Parameter(typeof(OrderDto), "orderDto");
            var visitor = new ReplaceVisitor();
            var result = visitor.Modify(expressionToTransform.Parameters[0], numParam);
            return result;
            
        }

        public static Expression<Func<OrderDto, bool>> ConvertExpression(Expression<Func<string,int, bool>> expression)
        {
            var jobAuditParameter = Expression.Parameter(typeof(OrderDto), "orderDto");
            var newExpression = Expression.Lambda<Func<OrderDto, bool>>(new ReplaceVisitor().Modify(expression.Body, jobAuditParameter), jobAuditParameter);
            return newExpression;
        }

        //public Expression Convert3(Expression<Func<DomainOrder, int, bool>> expressionToTransform)
        //{
        //    var body = expressionToTransform.Body;
        //    var targetParam = Expression.Parameter(typeof(OrderDto), "orderDto");
        //    var visitor = new ReplaceVisitor();
        //    //var result = visitor.Modify(expressionToTransform.Parameters[0], numParam);
        //    //return result;

        //}
    }



    class ReplaceVisitor : ExpressionVisitor
    {
        private ParameterExpression _parameter;

        public Expression Modify(Expression expression, ParameterExpression parameter)
        {
            this._parameter = parameter;
            return Visit(expression);
        }

        //protected override Expression VisitLambda<T>(Expression<T> node)
        //{
        //    //return Expression.Lambda<Func<OrderDto, bool>>(Visit(node.Body), Expression.Parameter(typeof(OrderDto)));
        //    return Expression.Lambda<Func<OrderDto, bool>>(Visit(node.Body), Expression.Parameter(typeof(int)));
        //}

        protected override Expression VisitParameter(ParameterExpression node)
        {
            if (node.Type == typeof(string))
            {
                return Expression.Property(_parameter, "ZipCode");
            }
            else if (node.Type == typeof(DateTime))
            {
                return Expression.Property(_parameter, "RanAt");
            }
            else if (node.Type == typeof(byte))
            {
                return Expression.Property(_parameter, "Result");
            }
            else if (node.Type == typeof(long))
            {
                return Expression.Property(_parameter, "Elapsed");
            }
            else if (node.Type == typeof (int))
            {
                return Expression.Property(_parameter, "DocId");

            }
            else if (node.Type == typeof (DomainOrder))
            {
                return Expression.Property(_parameter, "DocId");
            }
            throw new InvalidOperationException();
        }
    }

    public static class ParameterReplacer
    {
        // Produces an expression identical to 'expression'
        // except with 'source' parameter replaced with 'target' expression.     
        public static Expression<TOutput> Replace<TInput, TOutput>(Expression<TInput> expression,ParameterExpression source,Expression target)
        {
            return new ParameterReplacerVisitor<TOutput>(source, target).VisitAndConvert(expression);
        }

        private class ParameterReplacerVisitor<TOutput> : ExpressionVisitor
        {
            private ParameterExpression _source;
            private Expression _target;

            public ParameterReplacerVisitor(ParameterExpression source, Expression target)
            {
                _source = source;
                _target = target;
            }

            internal Expression<TOutput> VisitAndConvert<T>(Expression<T> root)
            {
                return (Expression<TOutput>)VisitLambda(root);
            }

            protected override Expression VisitLambda<T>(Expression<T> node)
            {
                // Leave all parameters alone except the one we want to replace.
                var parameters = node.Parameters.Where(p => p != _source);
                return Expression.Lambda<TOutput>(Visit(node.Body), parameters);
            }

            protected override Expression VisitParameter(ParameterExpression node)
            {
                // Replace the source with the target, visit other params as usual.
                return node == _source ? _target : base.VisitParameter(node);
            }
        }
    }
}
