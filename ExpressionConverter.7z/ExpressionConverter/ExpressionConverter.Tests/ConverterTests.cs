﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ExpressionConverter.Tests
{
    [TestClass]
    public class ConverterTests
    {
        [TestMethod]
        public void Converter_ConvertExpression_ReturnsNewExpression()
        {
            //Expression<Func<bool>> expressionOne = () => true;
            //Expression<Func<bool>> expressionTwo = () => true;
            //Expression<Func<bool>> myOtherExpression = () => expressionOne.Compile().Invoke() && expressionTwo.Compile().Invoke();
            Expression<Func<DomainOrder,int, bool>> expression = (o, id ) => o.OrderId == id;
            var target = new Converter();

            // act
            var result = target.ConvertExpression(expression);

            // assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void Converter_ConvertExpression2_ReturnsNewExpression()
        {
            //Expression<Func<bool>> expressionOne = () => true;
            //Expression<Func<bool>> expressionTwo = () => true;
            //Expression<Func<bool>> myOtherExpression = () => expressionOne.Compile().Invoke() && expressionTwo.Compile().Invoke();
            Expression<Func<DomainOrder, int, bool>> expression = (o, id) => o.OrderId == id;
            var target = new Converter();

            // act
            var result = target.Convert2(expression);

            // assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void Foo()
        {
            //Expression<Func<string, DateTime, byte, long, bool>> expression = (jobName, ranAt, resultCode, elapsed) => jobName == "Email Notifications" && resultCode == (byte)1;
            Expression<Func<string,int,bool>> expression = (zip, id) => zip == "38655" && id == 1;
            var criteria = Converter.ConvertExpression(expression);

            Assert.IsNotNull(criteria);
        }


        //private void Foo()
        //{
        //    Expression<Func<string, DateTime, byte, long, bool>> expression = (jobName, ranAt, resultCode, elapsed) => jobName == "Email Notifications" && resultCode == (byte)ResultCode.Failed;
        //    var criteria = ConvertExpression(expression);
        //}




    }
}
