﻿namespace DnxConsole.Domain.Common.Contracts
{
    public interface IDomainEvent // Just a marker interface
    {
    }
}
