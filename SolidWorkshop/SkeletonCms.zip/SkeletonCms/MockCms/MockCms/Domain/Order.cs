﻿namespace MockCms.Domain
{
    public class Order
    {
        public void CreateOrder()
        {
            // Order specific biz logic
        }
    }
}
